<footer class="blockquote-footer fixed-bottom">Get more amazing projects in <cite title="Source Title"><a href="https://codewithbish.com/projects/" target="_blank">codewithbish.com</a></cite></footer>
</body>
</html>